#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Dec 25 11:19:43 2019

@author: dansihong
"""
import pandas as pd
import asyncio
import websockets
import json
import nest_asyncio
import time
# import verifyOptionTicker
# import seaborn as sns
# import matplotlib.pyplot as plt
import numpy as np
import os
import sys
sys.path.append('/Users/dansihong/spyder/Project_Tushare/')
from TushareMonster import downloadBars
import math

nest_asyncio.apply()

def mkdir(path):
    # 去除首位空格
    path=path.strip()
    # 去除尾部 \ 符号
    path=path.rstrip("\\")
 
    # 判断路径是否存在
    # 存在     True
    # 不存在   False
    isExists=os.path.exists(path)
 
    # 判断结果
    if not isExists:
        # 如果不存在则创建目录
        # 创建目录操作函数
        os.makedirs(path) 
 
        print(path+' 创建成功')
        return True
    else:
        # 如果目录存在则不创建，并提示目录已存在
        print(path+' 目录已存在')
        return False
async def call_api(msg):
   async with websockets.connect('wss://www.deribit.com/ws/api/v2') as websocket:
       #print(websocket)
       #<websockets.client.WebSocketClientProtocol object at 0x11ddeb2e8>
       await websocket.send(msg)
       while websocket.open:
           response = await websocket.recv()
           # do something with the response...
           #print(type(response))
           #print(response)
           return(response)
       
def getOptionInstrumentList(b_show_sample=True,currency='BTC'):
    msg = \
    {
     "jsonrpc" : "2.0",
     "id" : 7627,
     "method" : "public/get_instruments",
     "params" : {
             "currency" : currency,
             "kind" : "option",
             "expired" : False
        }
    }
    loop=asyncio.get_event_loop()
    li_str=loop.run_until_complete(call_api(json.dumps(msg)))
    #loop.close()
    
    li_dict=json.loads(li_str)
    li_result=li_dict['result']
    sample_ticker=li_result[0]
    
    #print(li_result[0].keys())
    ins_name=sample_ticker['instrument_name']
    names=ins_name.split('-')
    if b_show_sample:
        print('sample instrument name:',(sample_ticker))
        print('split sameple\'s name:',names)
    else:
        print('已获得所有期权id')
    
    li_ins_names=[]
    for ticker in li_result:
        li_ins_names.append(ticker['instrument_name'])
    '''group_by_date={}
    for ticker in li_result:
        ins_name=ticker['instrument_name']
        names=ins_name.split('-')
        if names[1] in group_by_date.keys():
            group_by_date[names[1]].append(ins_name)
        else:
            group_by_date.update({names[1]:[ins_name]})'''
    #for keys in group_by_date.keys():
    #    print(group_by_date[keys])
    #    break
    
    
    return li_ins_names

def getDeribitOptionTickers(li_ins_names,
                            num_per_loop=15,###整个来异步似乎有问题，分成部分
                           b_save_ticks=True,
                           b_verify=False,#再次验证ticker完整性
                           b_show_sample=True,
                           ):
    
    #print(len(li_ins_names))
    tasks=[]
    for name in li_ins_names:
        tasks.append(call_api(json.dumps({"jsonrpc" : "2.0",
                                "id" : 8106,
                                "method" : "public/ticker",
                                "params" : {"instrument_name" : name}
                                })))
    #print(tasks)
    tickers_whole=[]
    
    now=time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time()))
    print('在%s开始爬数据'%now)
    for i in range(len(tasks)//num_per_loop+1):
        loop=asyncio.get_event_loop()
        sub_tasks=tasks[i*num_per_loop:(i+1)*num_per_loop]
        tickers= loop.run_until_complete(asyncio.gather(*sub_tasks))#iv=0的情况:1.有挂单iv算出来为0，或者没有挂单iv也算0
        #loop.close()
        #print(type(tickers))###list
        if len(tickers)==num_per_loop:
            tickers_whole+=tickers
            print('成 功 获 取 %d tickers, iter #%d'%(len(tickers),i+1))
        elif i==len(tasks)//num_per_loop and len(tickers)==(len(tasks)%num_per_loop):#最后一个loop
            tickers_whole+=tickers
            print('成 功 获 取 %d tickers, iter #%d'%(len(tickers),i+1))
        else:
            print('#########    ticker有缺失或者谬误！1    ########')
            return False
        
    if len(tickers_whole)!=len(tasks):
        print('#########    ticker有缺失或者谬误！2    ########')
        return False
    else:
        print('所有option ticker都已经获得了')
    if b_show_sample:
        print('sample ticker:',json.loads(tickers_whole[0]))
    tickerd=dataframize([json.loads(tickers_whole[i])['result'] for i in range(len(tickers_whole))])
    #时间标准化
    tickerd['std_date']=pd.to_datetime(tickerd['exp_date'])
    #把bidiv、askiv统一为iv，附加bidask的column
    df1=tickerd.copy()
    df1['bidask']=['bid' for i in range(len(tickerd))]
    df1['iv']=df1['bid_iv']
    df2=tickerd.copy()
    df2['bidask']=['ask' for i in range(len(tickerd))]
    df2['iv']=df2['ask_iv']
    #print(df1)
    #print(df2)
    tickerd=df1.append(df2,ignore_index=True)
    #排序
    tickerd=tickerd.sort_values(by=['std_date','strike','callput','bidask'])
    tickerd.reset_index(inplace=True,drop=True)
    if b_save_ticks:
        tickerd.to_csv('/Users/dansihong/spyder/Project_Option_volmap/csvs/'+'deribitOptionTicker_'+now+'.csv',index=False)
    if b_verify:
        # verifyOptionTicker.sortAndShow(tickerd)
        pass
    tickerd['recording_time']=[now for i in range(len(tickerd))]
    return tickerd,now

def dataframize(li):
    #将所有ticker中result的数据转化为可操作的df
    ins_name=li[0]['instrument_name'].split('-')
    li[0]['exp_date']=ins_name[1]
    li[0]['strike']=int(ins_name[2])
    li[0]['callput']=ins_name[3]
    li[0].update(li[0]['greeks'])
    li[0].update(li[0]['stats'])
    df=pd.DataFrame(li[0],index=[0])
    for i in range(1,len(li)):
        ins_name=li[i]['instrument_name'].split('-')
        li[i]['exp_date']=ins_name[1]
        li[i]['strike']=int(ins_name[2])
        li[i]['callput']=ins_name[3]
        li[i].update(li[i]['greeks'])
        li[i].update(li[i]['stats'])
        df=df.append(pd.DataFrame(li[i],index=[0]),ignore_index=True)
    #print(df)
    return df

def getDeribitPerpetualTicker():
    msg = \
        {
            "jsonrpc" : "2.0",
            "id" : 8106,
            "method" : "public/ticker",
            "params" : {
                "instrument_name" : "BTC-PERPETUAL"
                }
        }
    
    loop=asyncio.get_event_loop()
    response=loop.run_until_complete(call_api(json.dumps(msg)))
    # print(response)
    last_price=json.loads(response)['result']['last_price']
    # print(last_price)
    return last_price

def IV_ATM():
    _=getOptionInstrumentList()
    
    dates=[]
    strikes=[]
    CP=[]
    for name in _:
        temp=name.split('-')
        date,strike,callput=temp[1],temp[2],temp[3]
        dates.append(date)
        strikes.append(strike)
        CP.append(callput)
    totalLists=pd.DataFrame({'name':_,'date':dates,'strike':strikes,'callput':CP},index=[i for i in range(len(_))])
    # print(totalLists)
    
    
    
    dates=[]
    first_round_names=[]
    for s in totalLists.name.values:
        date=s.split('-')[1]
        if date in dates:
            continue
        else:
            dates.append(date)
            first_round_names.append(s)
    tickerd,now=getDeribitOptionTickers(first_round_names)
    # print(first_round_names)
    # print(tickerd.columns)
    # print(tickerd)
    
    second_round_names=[]
    underlying_price=getDeribitPerpetualTicker()#就是现货价格
    for i in range(0,len(tickerd),2):
        date=tickerd.exp_date[i]
        df=totalLists.loc[(totalLists.date==date)]
        strikes=df.strike.values
        # print(strikes)
        posi_diffs={}
        nega_diffs={}
        for s in strikes:
            diff=float(s)-underlying_price
            if diff>=0:
                posi_diffs.update({diff:s})
            else:
                nega_diffs.update({abs(diff):s})
        # print(df.columns)
        # print('------')
        posi_min=min(posi_diffs)
        nega_min=min(nega_diffs)
        # print(_min)
        big_strike=posi_diffs[posi_min]
        small_strike=nega_diffs[nega_min]
        # print(small_strike,underlying_price,big_strike,'-----')
        second_round_names.append(df.loc[df.strike==big_strike].name.values[0])
        second_round_names.append(df.loc[df.strike==small_strike].name.values[0])
    # print(second_round_names)
    
    tickerd,now=getDeribitOptionTickers(second_round_names)
    # print(tickerd)

    # print(tickerd.columns)
    dates=[]
    strikes=[]
    ivs=[]
    for i in range(int(len(tickerd)/2)):
        dates.append(tickerd.exp_date[i*2])
        strikes.append((tickerd.strike[i*2]))
        ivs.append((tickerd.mark_iv[i*2]))
    d1=pd.DataFrame({'date':dates,'strike':strikes,'mark_iv':ivs},index=[i for i in range(len(dates))])
    # print(d1)
    dates=[]
    strikes=[]
    ivs=[]
    for i in range(int(len(d1)/2)):
        dates.append(d1.date[i*2])
        strikes.append(underlying_price)
        small_strike=float(d1.strike[i*2])
        big_strike=float(d1.strike[i*2+1])#线性
        small_iv=float(d1.mark_iv[i*2])
        big_iv=float(d1.mark_iv[i*2+1])
        interpol_iv=float(((big_strike-underlying_price)*small_iv+(underlying_price-small_strike)*big_iv)/(big_strike-small_strike))
        ivs.append(
            interpol_iv
            )
        print(small_iv,small_strike,big_iv,big_strike,interpol_iv,underlying_price)
    
    

    
        
def getHistoricalVol_N_priceChange():
    df=downloadBars(
        exchange='okex',
        symbol='btcusdt',
        freq='60min',
        start_date='20160101',
        end_date='uptodate',
        show_checks=False,
        show_data=False,
        )[0]
    prices=df.close.values
    # print(len(prices))
    histVol=calcHistoricalVol(prices,days=3*24,multiply=365*24)
    # print(len(histVol))
    df['volatility']=histVol
    ddd=df[['date','volatility','close']]
    
    closes=ddd.close.values
    price_change=list(np.diff(closes))
    price_change_percent=[np.nan]
    for i in range(len(price_change)):
        price_change_percent.append(price_change[i]/closes[i]*100)
    ddd['price_change%']=price_change_percent
    # print(ddd.head(60))

    return ddd
    
def calcHistoricalVol(prices,days=7,multiply=365):
    histVol=[np.nan for i in range(days)]
    for i in range(days,len(prices)):
        daily_change=[]
        for j in range(i-days+1,i+1):
            daily_change.append(math.log(prices[j]/prices[j-1]))
        mean=sum(daily_change)/len(daily_change)
        _=0
        for j in daily_change:
            _+=(j-mean)**2
        _=math.sqrt(_/(days-1)*multiply)
        histVol.append(_*100)
    return histVol
            
            
        
if __name__=='__main__':
    histVol=getHistoricalVol_N_priceChange()

    # IV_ATM()
    # getDeribitPerpetualTicker()
    