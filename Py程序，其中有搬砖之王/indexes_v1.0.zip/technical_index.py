#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Dec 20 10:34:28 2019

@author: dansihong
"""
import tushare as ts
import pandas as pd
import time
import datetime
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import talib
import websockets
import sys
sys.path.append('/Users/dansihong/spyder/Project_Tushare/')
from TushareMonster import downloadBars




def getTechnicals():
    df=downloadBars(
        exchange='okex',
        symbol='btcusdt',
        freq='60min',
        start_date='20160101',
        end_date='uptodate',
        show_checks=False,
        show_data=False,
        )[0]
    
    # print('data\n',df.columns)
    
    high=df.high.values
    low=df.low.values
    close=df.close.values
    # print(close)
    # print(df)
    for p in [7*24,30*24]:
        df['MA'+str(int(p/24))] = talib.MA(np.array(close), timeperiod=p)
    for p in [12*24,26*24]:
        pass
        # df['EMA'+str(p)] = talib.EMA(np.array(close), timeperiod=p)
    df['MACD'],df['MACDsignal'],df['MACDhist'] = talib.MACD(np.array(close),
                            fastperiod=5*24, slowperiod=10*24, signalperiod=4*24)
    for p in [6*24]:
        df['RSI'+str(int(p/24))]=talib.RSI(np.array(close), timeperiod=p)     #RSI的天数一般是6、12、24
    df['MOM10']=talib.MOM(np.array(close), timeperiod=10*24)
    
    pivot=(close+high+low)/3
    df['pivot']=pivot
    df['resistance1']=2*pivot-low
    df['support1']=2*pivot-high
    df['resistance2']=pivot+high-low
    df['support2']=pivot-high+low
    df['resistance3']=2*pivot-low+high-low
    df['support3']=2*pivot-high-high+low
    
    # print(df)
    return df
    # df.to_csv('/Users/dansihong/spyder/Project_DataGuru/Project_indice/technical_index.csv')
    
    
    
    
    
if __name__ == "__main__":
    getTechnicals()