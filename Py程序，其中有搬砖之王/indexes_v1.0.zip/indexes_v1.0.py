#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Dec 28 12:13:33 2019

@author: dansihong
"""
import pandas as pd
import technical_index
import historical_N_spot_implied_vol
import get_basis
















def getIndexes():
    d1=technical_index.getTechnicals()
    d2=historical_N_spot_implied_vol.getHistoricalVol_N_priceChange()
    d3=get_basis.getBasis()
    d4=d1.merge(d2,how='outer',on='date')
    d4=d4.merge(d3,how='outer',on='date')
    
    
    
    d4.drop(['close_y','future_close','coin_close','vol','open','high','low'],axis=1,inplace=True)
    d4.rename(columns={'close_x':'close'},inplace=True)
    
    print(d4.columns)
    
    # d4=d4.T
    d4.to_csv('/Users/dansihong/spyder/Project_DataGuru/Project_indexes/indexes_v1.1.csv',header=True,index=False)
    
if __name__=='__main__':
    d=getIndexes()