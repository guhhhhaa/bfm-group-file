#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Dec 27 15:47:24 2019

@author: dansihong
"""

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Dec 20 16:58:22 2019

@author: dansihong
"""
#这是一个停工项目，是为了得到option hist price/iv
import pandas as pd
import asyncio
import websockets
import json
import nest_asyncio
import time
# import verifyOptionTicker
# import seaborn as sns
# import matplotlib.pyplot as plt
import numpy as np
import os
import getpass
from pyecharts.faker import Faker
from pyecharts import options as opts
from pyecharts.charts import Surface3D
import datetime

nest_asyncio.apply()

def mkdir(path):
    # 去除首位空格
    path=path.strip()
    # 去除尾部 \ 符号
    path=path.rstrip("\\")
 
    # 判断路径是否存在
    # 存在     True
    # 不存在   False
    isExists=os.path.exists(path)
 
    # 判断结果
    if not isExists:
        # 如果不存在则创建目录
        # 创建目录操作函数
        os.makedirs(path) 
 
        print(path+' 创建成功')
        return True
    else:
        # 如果目录存在则不创建，并提示目录已存在
        print(path+' 目录已存在')
        return False
async def call_api(msg):
   async with websockets.connect('wss://www.deribit.com/ws/api/v2') as websocket:
       #print(websocket)
       #<websockets.client.WebSocketClientProtocol object at 0x11ddeb2e8>
       await websocket.send(msg)
       while websocket.open:
           response = await websocket.recv()
           # do something with the response...
           #print(type(response))
           #print(response)
           return(response)
               
def getOptionInstrumentList(b_show_sample=True,currency='BTC'):
    msg = \
    {
     "jsonrpc" : "2.0",
     "id" : 7627,
     "method" : "public/get_instruments",
     "params" : {
             "currency" : currency,
             "kind" : "option",
             "expired" : False
        }
    }
     
    loop=asyncio.get_event_loop()
    li_str=loop.run_until_complete(call_api(json.dumps(msg)))
    #loop.close()
    
    li_dict=json.loads(li_str)
    li_result=li_dict['result']
    sample_ticker=li_result[0]
    
    #print(li_result[0].keys())
    ins_name=sample_ticker['instrument_name']
    names=ins_name.split('-')
    if b_show_sample:
        print('sample instrument name:',(sample_ticker))
        print('split sameple\'s name:',names)
    else:
        print('已获得所有期权id')
    
    li_ins_names=[]
    for ticker in li_result:
        li_ins_names.append(ticker['instrument_name'])
    '''group_by_date={}
    for ticker in li_result:
        ins_name=ticker['instrument_name']
        names=ins_name.split('-')
        if names[1] in group_by_date.keys():
            group_by_date[names[1]].append(ins_name)
        else:
            group_by_date.update({names[1]:[ins_name]})'''
    #for keys in group_by_date.keys():
    #    print(group_by_date[keys])
    #    break
    
    
    return li_ins_names

def getDeribitOptionTickers(li_ins_names,
                            num_per_loop=15,###整个来异步似乎有问题，分成部分
                           b_save_ticks=True,
                           b_verify=False,#再次验证ticker完整性
                           b_show_sample=True,
                           ):
    
    #print(len(li_ins_names))
    tasks=[]
    for name in li_ins_names:
        tasks.append(call_api(json.dumps({"jsonrpc" : "2.0",
                                "id" : 8106,
                                "method" : "public/ticker",
                                "params" : {"instrument_name" : name}
                                })))
    #print(tasks)
    tickers_whole=[]
    
    now=time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time()))
    print('在%s开始爬数据'%now)
    for i in range(len(tasks)//num_per_loop+1):
        loop=asyncio.get_event_loop()
        sub_tasks=tasks[i*num_per_loop:(i+1)*num_per_loop]
        tickers= loop.run_until_complete(asyncio.gather(*sub_tasks))#iv=0的情况:1.有挂单iv算出来为0，或者没有挂单iv也算0
        #loop.close()
        #print(type(tickers))###list
        if len(tickers)==num_per_loop:
            tickers_whole+=tickers
            print('成 功 获 取 %d tickers, iter #%d'%(len(tickers),i+1))
        elif i==len(tasks)//num_per_loop and len(tickers)==(len(tasks)%num_per_loop):#最后一个loop
            tickers_whole+=tickers
            print('成 功 获 取 %d tickers, iter #%d'%(len(tickers),i+1))
        else:
            print('#########    ticker有缺失或者谬误！1    ########')
            return False
        
    if len(tickers_whole)!=len(tasks):
        print('#########    ticker有缺失或者谬误！2    ########')
        return False
    else:
        print('所有option ticker都已经获得了')
    if b_show_sample:
        print('sample ticker:',json.loads(tickers_whole[0]))
    tickerd=dataframize([json.loads(tickers_whole[i])['result'] for i in range(len(tickers_whole))])
    #时间标准化
    tickerd['std_date']=pd.to_datetime(tickerd['exp_date'])
    #把bidiv、askiv统一为iv，附加bidask的column
    df1=tickerd.copy()
    df1['bidask']=['bid' for i in range(len(tickerd))]
    df1['iv']=df1['bid_iv']
    df2=tickerd.copy()
    df2['bidask']=['ask' for i in range(len(tickerd))]
    df2['iv']=df2['ask_iv']
    #print(df1)
    #print(df2)
    tickerd=df1.append(df2,ignore_index=True)
    #排序
    tickerd=tickerd.sort_values(by=['std_date','strike','callput','bidask'])
    tickerd.reset_index(inplace=True,drop=True)
    if b_save_ticks:
        tickerd.to_csv('/Users/dansihong/spyder/Project_Option_volmap/csvs/'+'deribitOptionTicker_'+now+'.csv',index=False)
    if b_verify:
        # verifyOptionTicker.sortAndShow(tickerd)
        pass
    return tickerd,now

def dataframize(li):
    #将所有ticker中result的数据转化为可操作的df
    ins_name=li[0]['instrument_name'].split('-')
    li[0]['exp_date']=ins_name[1]
    li[0]['strike']=int(ins_name[2])
    li[0]['callput']=ins_name[3]
    li[0].update(li[0]['greeks'])
    li[0].update(li[0]['stats'])
    df=pd.DataFrame(li[0],index=[0])
    for i in range(1,len(li)):
        ins_name=li[i]['instrument_name'].split('-')
        li[i]['exp_date']=ins_name[1]
        li[i]['strike']=int(ins_name[2])
        li[i]['callput']=ins_name[3]
        li[i].update(li[i]['greeks'])
        li[i].update(li[i]['stats'])
        df=df.append(pd.DataFrame(li[i],index=[0]),ignore_index=True)
    #print(df)
    return df

def dataframe_chazhi(df):
    #print(df.columns[0])
    pass

def draw3DVolmap(currency='BTC',
               b_uptodate=False,
               b_4maps=True,
               b_4_1000s=False,
               vmax=150):
    #init
    if b_uptodate:
        li_ins_names=getOptionInstrumentList(currency=currency)
        df,now=getDeribitOptionTickers(li_ins_names)
    else:
        dir='/Users/dansihong/spyder/Project_Option_volmap/csvs/deribitOptionTicker_2019-12-21 15:46:36.csv'
        df=pd.read_csv(dir)
        now=dir.split('_')[3].split('.')[0]
    # #求热力图的vmin
    # li=list(df.iv.values)
    # while 0 in li:
    #     li.remove(0)
    # while np.nan in li:
    #     li.remove(np.nan)
    # vmin=min(li)
    # print('set vmin as such other than 0 and nan:',vmin)
    #数据筛除
    df_1000=df.copy()
    for i in range(len(df_1000)):
        try:
            if df_1000.strike[i]%1000!=0:
                df_1000.drop([i],inplace=True)
        except Exception:
            print(type(df_1000.strike[i]))
            return False
    df_1000.reset_index(drop=True,inplace=True)
    #数据插值
    # df_chazhi=dataframe_chazhi(df)
    #画图
    if b_4maps:#4个曲面->one mark iv
        for callput in ['C','P']:
            for bidask in ['bid','ask']:
                data = df.loc[(df['callput']==callput)&(df['bidask']==bidask)].copy()
                
                # df2=returnDataChazhi(data)
                # df2.to_csv('/Users/dansihong/spyder/Project_DataGuru/Project_indexes/data_volmap_'+('call' if callput=='C' else 'put')+'_'+bidask+'.csv')
                s,df=drawEcharts(data)
                s.render()
                return df

    
def returnDataChazhi(data,b_return_df=True):#剔除所有0iv后插值
    
    
    ivs=data.mark_iv.values
    
    std_dates=data.std_date.values
    all_possible_dates=list(set(std_dates))
    all_possible_dates.sort()
    print(all_possible_dates)

    strikes=data.loc[(data['iv']>0)].strike.values
    all_possible_strikes=list(set(strikes))
    all_possible_strikes.sort()
    # print(all_possible_strikes)
    
    elements=[]
    li_date=[]
    li_strike=[]
    li_iv=[]
    
    k=0
    for date in all_possible_dates:#按到期日分步插值
        k+=1
        print()
        df=data.loc[(data['std_date']==date)&(data['iv']>0)] #该到期日下有正iv的ticker
        strike_=df.strike.values#一切有iv的strike
        max_,min_=max(strike_),min(strike_)
        for s in all_possible_strikes:
            s=int(s)
            if s<min_ or s>max_:
                # l=[date,s,'-']
                # elements.append(l)
                # print(l,)
                li_date.append(date)
                li_strike.append(s)
                li_iv.append('-')
            elif s in strike_:
                _=float(df.loc[(df['strike']==s)].mark_iv.values[0])
                # l=[date,s,_]
                # elements.append(l)
                # print(l,)
                li_date.append(date)
                li_strike.append(s)
                li_iv.append(_)
            else:
                _big=df.loc[(df['strike']>s)]
                _small=df.loc[(df['strike']<s)]
                big_iv=_big.mark_iv.values[0]
                big_strike=_big.strike.values[0]
                small_iv=_small.mark_iv.values[-1]
                small_strike=_small.strike.values[-1]
                # l=[date,s,float(((big_strike-s)*small_iv+(s-small_strike)*big_iv)/(big_strike-small_strike))]
                # elements.append(l)
                # print(l,small_iv,small_strike,big_iv,big_strike)
                li_date.append(date)
                li_strike.append(float(((big_strike-s)*small_iv+(s-small_strike)*big_iv)/(big_strike-small_strike)))
                li_iv.append('-')
        if b_return_df:
            
            return pd.DataFrame({'date':li_date,'strike':li_strike,'iv':li_iv},index=[i for i in range(len(li_date))])

def drawEcharts(data):#剔除所有0iv后插值
    
    
    # ivs=data.mark_iv.values
    
    std_dates=data.std_date.values
    all_possible_dates=list(set(std_dates))
    all_possible_dates.sort()
    print(all_possible_dates)

    strikes=data.loc[(data['mark_iv']>0)].strike.values
    all_possible_strikes=list(set(strikes))
    all_possible_strikes.sort()
    # print(all_possible_strikes)
    
    elements=[]
    li_date=[]
    li_strike=[]
    li_iv=[]
    
    # 数据填入
    k=0
    for date in all_possible_dates:#按到期日分步插值
        k+=1
        print()
        df=data.loc[(data['std_date']==date)&(data['mark_iv']>0)] #该到期日下有正iv的ticker
        strike_=df.strike.values#一切有iv的strike
        max_,min_=max(strike_),min(strike_)
        for s in all_possible_strikes:
            s=int(s)
            
            if s<min_ or s>max_:
                l=[date,s,'-']
                elements.append(l)
                print(l,)
                
                li_date.append(date)
                li_strike.append(s)
                li_iv.append('-')
                
            elif s in strike_:
                _=float(df.loc[(df['strike']==s)].mark_iv.values[0])
                l=[date,s,_]
                elements.append(l)
                print(l,)
                
                li_date.append(date)
                li_strike.append(s)
                li_iv.append(_)
                
            else:
                _big=df.loc[(df['strike']>s)]
                _small=df.loc[(df['strike']<s)]
                big_iv=_big.mark_iv.values[0]
                big_strike=_big.strike.values[0]
                small_iv=_small.mark_iv.values[-1]
                small_strike=_small.strike.values[-1]
                l=[date,s,float(((big_strike-s)*small_iv+(s-small_strike)*big_iv)/(big_strike-small_strike))]
                elements.append(l)
                print(l,small_iv,small_strike,big_iv,big_strike)
                
                li_date.append(date)
                li_strike.append(float(((big_strike-s)*small_iv+(s-small_strike)*big_iv)/(big_strike-small_strike)))
                li_iv.append('-')
        print(len(elements))
    # 填完了
    
    
    print(elements)
    c = (
        Surface3D()
        .add(
            "",
            elements,
            xaxis3d_opts=opts.Axis3DOpts(type_="category"),
            yaxis3d_opts=opts.Axis3DOpts(type_="value"),
            grid3d_opts=opts.Grid3DOpts(),
        )
        .set_global_opts(
            title_opts=opts.TitleOpts(title="volmap"),
            visualmap_opts=opts.VisualMapOpts(
                max_=500, min_=0, range_color=Faker.visual_color
            ),
        )
    )
    return c,pd.DataFrame({'date':li_date,'strike':li_strike,'iv':li_iv},index=[i for i in range(len(li_date))])
    
    
    
    
    
    
if __name__=='__main__':
    names=getOptionInstrumentList()
    print(names)
    name=names[0]
    ts = datetime.datetime.now().timestamp()
    ts=int(ts)*1000
    print(1554373800000,ts)
    
    msg = \
{
  "jsonrpc" : "2.0",
  "id" : 833,
  "method" : "public/get_tradingview_chart_data",
  "params" : {
    "instrument_name" : name,
    "start_timestamp" : 1554373800000,
    "end_timestamp" : ts,
    "resolution" : "60"
  }
}
    loop=asyncio.get_event_loop()
    res=json.loads(loop.run_until_complete(call_api(json.dumps(msg))))
    for k in res['result'].keys():
        item=res['result'][k]
        print('\n',k,len(item))
        
        print(item)




