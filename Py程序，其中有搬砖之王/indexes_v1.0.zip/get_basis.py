#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Dec 27 12:45:20 2019

@author: dansihong
"""

import sys
sys.path.append('/Users/dansihong/spyder/Project_Tushare/')
from TushareMonster import downloadBars
import pandas as pd
def getBasis():
    
    future=downloadBars(exchange='future_okex',symbol='btcusdt',freq='60min',start_date='20160101',end_date='uptodate',show_checks=False,show_data=False,b_isfuture=True)[0]
    future.rename(columns={'close':'future_close'},inplace=True)
    coin=downloadBars(exchange='okex',symbol='btcusdt',freq='60min',start_date='20160101',end_date='uptodate',show_checks=False,show_data=False,)[0]
    coin.rename(columns={'close':'coin_close'},inplace=True)
    # print(future,'\n',coin)
    future_coin=future.merge(coin,how='inner',on='date')
    # print(future_coin)
    future_coin['基差']=future_coin.future_close.values-future_coin.coin_close.values
    basis=future_coin[['date','future_close','coin_close','基差']]
    # print(basis)
    return basis

if __name__ =='__main__':
    getBasis()