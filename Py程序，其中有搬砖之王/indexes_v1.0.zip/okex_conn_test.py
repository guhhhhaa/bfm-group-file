#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Dec 25 10:23:49 2019

@author: dansihong
"""

import random
import time
import pandas as pd
import numpy as np
import datetime
import sys
import json
from websocket import create_connection

console = sys.stdout #得到当前输出方向， 也就是控制台
file = open("apocalypse.txt", 'w')
sys.stdout = file #重定向到文件
    
    
    
ws = create_connection("ws://echo.websocket.org/")
print("Sending 'Hello, World'...")
ws.send("Hello, World")
print("Sent")
print("Receiving...")
result =  ws.recv()
print("Received '%s'" % result)
ws.close()

x=[1,'23']
print(set(x))


ws= create_connection("wss://real.okex.com:8443/ws/v3")
msg={"op": "subscribe", "args": ["spot/candle86400s:BTC-USDT"]}
ws.send(json.dumps(msg))
res=ws.recv()
print(res)
ws.close()
import requests
def get_server_time():
    url = "https://www.okex.com/api/general/v3/time"
    response = requests.get(url)
    if response.status_code == 200:
        return response.json()['iso']
    else:
        return ""
    
# print('now:',get_server_time())
data = {
 'state': ['Ohio', 'Ohio', 'Ohio', 'Nevada', 'Nevada'],
'year': [2000, 2000, 2002, 2001, 2002],
'pop': [1.5, 1.7, 3.6, 2.4, 2.9]}
x=pd.DataFrame(data)
df=x.loc[x.state=='Ohio']
print(df)
df=df.loc[df.year==20]
print(len(df))